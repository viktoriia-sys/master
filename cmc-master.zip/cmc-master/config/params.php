<?php

return [
    'siteEmail' => 'cmc36@mail.ru',
    'sitePhone'  => '+7 920 224 46 62'
];
