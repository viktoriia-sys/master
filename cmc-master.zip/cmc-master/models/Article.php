<?php

namespace app\models;

use Yii;

class Article extends \yii\db\ActiveRecord
{

    public static function tableName()
    {
        return 'article';
    }

    public function rules()
    {
        return [
            [['url', 'link', 'title', 'description', 'short_text', 'h1', 'text', 'date'], 'required'],
            [['text'], 'string'],
            [['date'], 'safe'],
            [['url', 'link', 'title', 'description', 'short_text'], 'string', 'max' => 250],
            [['h1'], 'string', 'max' => 100],
            [['url'], 'unique'],
        ];
    }

    
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'url' => 'Url',
            'link' => 'Link',
            'title' => 'Title',
            'description' => 'Description',
            'short_text' => 'Short Text',
            'h1' => 'H1',
            'text' => 'Text',
            'date' => 'Date',
        ];
    }
}
