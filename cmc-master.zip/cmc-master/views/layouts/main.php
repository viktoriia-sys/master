<?php

use app\widgets\Alert;
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;
use yii\helpers\Url;

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php $this->registerCsrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body>
<?php $this->beginBody() ?>

<div class="top-bar">
		<div class="container-fluid">
			<div class="row">
				<div class="col-md-6 col-sm-6">
					<div class="left-top">
						<div class="email-box">
							<a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i><?=  Yii::$app->params['siteEmail'];?> </a>
						</div>
						<div class="phone-box">
							<a href="tel:1234567890"><i class="fa fa-phone" aria-hidden="true"></i><?=  Yii::$app->params['sitePhone'];?></a>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-sm-6">
					<div class="right-top">
						<div class="social-box">
							<ul>
								<li><a href="#"><i class="fa fa-vk" aria-hidden="true"></i></a></li>
							<ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	 <header class="header header_style_01">
        <nav class="megamenu navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?= Url::home()?>">
					  <?= Html::img("@web/images/logos/logo2.jpg", ['alt' => 'СпецМонтажСервис логотип'])?>
				    </a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a class="active" href="<?= Url::home()?>">СпецМонтажСервис</a></li>
                        <li><a href="<?= Url::to(['site/about']) ?>">О нас</a></li>
                        <li><a href="<?= Url::to(['site/prices']) ?>">Цены</a></li>
                        <li><a href="<?= Url::to(['site/services']) ?>">Услуги</a></li>
                        <li><a href="<?= Url::to(['site/works']) ?>">Работы</a></li>
                        <li><a href="<?= Url::to(['blog/index']) ?>">Блог</a></li>
                        <!--<li><a href="<?= Url::to(['site/faq']) ?>">FAQ</a></li>-->
						<li><a href="<?= Url::to(['site/contact']) ?>">Контакты</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>
	
	


        <?= Breadcrumbs::widget([
            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
        ]) ?>
        <?= Alert::widget() ?>
		
		
        <?= $content ?>


<div class="copyrights">
        <div class="container">
            <div class="footer-distributed">
                <div class="footer-left">                   
                    <p class="footer-company-name">СпецМонтажСервис </p>
                </div>

                
            </div>
        </div>
    </div>

    <a href="#" id="scroll-to-top" class="dmtop global-radius"><i class="fa fa-angle-up"></i></a>
	

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
