<?php
use yii\helpers\Html;
use yii\helpers\Url;
?>
<div class="slider-area">
		<div class="slider-wrapper owl-carousel">
			<div class="slider-item home-one-slider-otem slider-item-four slider-bg-one">
				<div class="container">
					<div class="row">
						<div class="slider-content-area">
							<div class="slide-text">
								<h1>Монтаж <span>винтовых свай</span> Воронеж</h1>
								<p class = "mywhite">
								Надежный свайный фундамент с гарантией 3 года<br>
								Любой заказ выполняем за 1 день без предоплаты<br>
								Свой парк спецтехники: самоходная установка Гудвинт. Сваекрут Feller SV-15
								</p>
								<div class="slider-content-btn">
									<a class="button btn btn-light btn-radius btn-brd" href="tel:+7 920 224 46 62"><?=  Yii::$app->params['sitePhone'];?></a>
									<a class="button btn btn-light btn-radius btn-brd" href="mailto:cmc36@mail.ru"><?=  Yii::$app->params['siteEmail'];?> </a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		
		</div>
	</div>

    <div id="about" class="section wb">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="message-box">
                        
                        <h2>Почему мы рекомендуем заказать свайно-винтовой фундамент?</h2>
                        <p class="lead">Основа надежного свайно-винтового фундамента —  
						конструкторский расчёт с учетом геологии участка.</p>
                        <p>
						Свайный фундамент в разы дешевле других видов фундамента.<br>
                        Он имеет высокую скорость монтажа, не дает усадки и можно сразу строить.<br>
                        У вас заболоченная местность, перепады высот, грунтовые воды?<br>
                        Не проблема!<br>
                        Свайные конструкции легко ввинчиваются в мягкую или твердую почву, буквально как "саморезы".<br>
                        Дом на свайном основании простоит не меньше 50 лет без капитального ремонта фундамента.<br>
                       <strong>СпецМонтажСервис - Закажите бесплатный замер и расчет сейчас!</strong>

						</p>

                        <a href="tel:+7 920 224 46 62" class="btn btn-light btn-radius btn-brd grd1">Звоните <?=  Yii::$app->params['sitePhone'];?></a>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="post-media wow fadeIn">
					    <?= Html::img("@web/images/youtube.png", ['alt' => 'Почему мы рекомендуем заказать именно свайно-винтовой фундамент?' , 'class' => 'img-responsive img-rounded'])?>
                            <a href="https://www.youtube.com/watch?v=Mj0l6_PORZ0" data-rel="prettyPhoto[gal]" class="playbutton"><i class="flaticon-play-button"></i>
							</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
	 <h3 class = "mycenter">Ваши выгоды</h3>
	
	<div id="about" class="section wb">
        <div class="container">
           <div class="row text-center">
		  
				<div class="col-md-3 col-sm-6">
					<div class="about-item">
						<div class="about-icon">
							<span class="icon icon-magic-wand"></span>
						</div>
						<div class="about-text">
							<h3> <a href="#">Надежность </a></h3>
							<p>Сваи всегда в наличии, собственное производство<br>
							 ГОСТ 10704-91 и 10705-80 со стенкой 4 мм по всей длине
						</p>
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6">
					<div class="about-item">
						<div class="about-icon">
							<span class="icon icon-magic-wand"></span>
						</div>
						<div class="about-text">
							<h3> <a href="#">Экономия </a></h3>
							<p>Без переплат и посредников <br>ВЫЕЗД НА ЗАМЕР И РАСЧЕТ, БЕСПЛАТНО<br>
							Без предоплаты, оплата по факту</p>
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6">
					<div class="about-item">
						<div class="about-icon">
							<span class="icon icon-magic-wand"></span>
						</div>
						<div class="about-text">
							<h3> <a href="#">Сервис </a></h3>
							<p>Выезжаем оперативно Устанавливаем сваи в любое время года и в любую погоду<br> 
                             Любой заказ выполняем за 1 день</p>
						</div>
					</div>
				</div>
				<div class="col-md-3 col-sm-6">
					<div class="about-item">
						<div class="about-icon">
							<span class="icon icon-magic-wand"></span>
						</div>
						<div class="about-text">
							<h3> <a href="#">Комфорт</a></h3>
							<p>Полная уборка строительных отходов на территории после монтажа</p>
						</div>
					</div>
				</div>
			</div>
        </div>
    </div>
	
	<div id="services" class="parallax section lb">
        <div class="container">
            <div class="section-title text-center">
                <h3>СпецМонтажСервис | Монтаж винтовых свай</h3>
                <p class="lead">Монтируем свайно-винтовые фундаменты погружением жб свай,
				строительством пирсов и причалов. 
				Выполняем берегоукрепительные работы в т. ч. шпунтом ПВХ.</p>
            </div>
			
			

            <div class="owl-services owl-carousel owl-theme">
                <div class="service-widget">
                    <div class="post-media wow fadeIn">
                        <?= Html::img("@web/images/service_01.jpg", ['alt' => 'Фундамент на сваях' , 'class' => 'img-responsive img-rounded'])?>
                    </div>
					<div class="service-dit">
						<h3>Фундаменты на сваях</h3>
						<!--<p>Aliquam sagittis ligula et sem lacinia, ut facilisis enim sollicitudin.
						Proin nisi est, convallis nec purus vitae, iaculis posuere sapien.
						Cum sociis natoque.</p>-->
					</div>
                </div>
                <!-- end service -->

                <div class="service-widget">
                    <div class="post-media wow fadeIn">
                        <?= Html::img("@web/images/service_02.jpg", ['alt' => 'Ограждения на сваях' , 'class' => 'img-responsive img-rounded'])?>
                        
                    </div>
					<div class="service-dit">
						<h3>Ограждения на сваях</h3>
						<!--<p>Duis at tellus at dui tincidunt scelerisque nec sed felis.
						Suspendisse id dolor sed leo rutrum euismod. Nullam vestibulum
						fermentum erat. It nam auctor. </p>-->
					</div>
                </div>
                <!-- end service -->

                <div class="service-widget">
                    <div class="post-media wow fadeIn">
                        <?= Html::img("@web/images/service_03.jpg", ['alt' => 'Шпунт' , 'class' => 'img-responsive img-rounded'])?>
                       
                    </div>
					<div class="service-dit">
						<h3>Шпунт</h3>
						<!--<p>Etiam materials ut mollis tellus, vel posuere nulla.
						Etiam sit amet lacus vitae massa sodales aliquam at eget quam.
						Integer ultricies et magna quis accumsan.</p>-->
					</div>
                </div>
                <!-- end service -->

              </div><!-- end row -->
			  
			  
			  
			  <div class="owl-services owl-carousel owl-theme">
                <div class="service-widget">
                    <div class="post-media wow fadeIn">
                        <?= Html::img("@web/images/service_04.jpg", ['alt' => 'Заборы' , 'class' => 'img-responsive img-rounded'])?>
                       
                    </div>
					<div class="service-dit">
						<h3>Заборы</h3>
						<!--<p>Aliquam sagittis ligula et sem lacinia,
						ut facilisis enim sollicitudin. Proin nisi est, 
						convallis nec purus vitae, iaculis posuere sapien. Cum sociis natoque.</p>-->
					</div>
                </div>
                <!-- end service -->

                <div class="service-widget">
                    <div class="post-media wow fadeIn">
                        <?= Html::img("@web/images/service_05.jpg", ['alt' => 'Пирсы и Причалы' , 'class' => 'img-responsive img-rounded'])?>
                       
                    </div>
					<div class="service-dit">
						<h3>Пирсы и Причалы</h3>
						<!--<p>Duis at tellus at dui tincidunt scelerisque nec sed felis. 
						Suspendisse id dolor sed leo rutrum euismod. Nullam vestibulum
						fermentum erat. It nam auctor. </p>-->
					</div>
                </div>
                <!-- end service -->

                <div class="service-widget">
                    <div class="post-media wow fadeIn">
                        <?= Html::img("@web/images/service_06.jpg", ['alt' => 'Берегоукрепление' , 'class' => 'img-responsive img-rounded'])?>
                       
                    </div>
					<div class="service-dit">
						<h3>Берегоукрепление</h3>
						<!--<p>Etiam materials ut mollis tellus, vel posuere nulla. 
						Etiam sit amet lacus vitae massa sodales aliquam at eget quam.
						Integer ultricies et magna quis accumsan.</p>-->
					</div>
                </div>
                <!-- end service -->

              </div><!-- end row -->
			  
			  <hr class="hr1">

            <div class="text-center">
			<a data-scroll href="<?= Url::to(['site/works']) ?>" class="btn btn-light btn-radius btn-brd">Смотрите наши работы</a>
                <!--<a data-scroll href="#portfolio" class="btn btn-light btn-radius btn-brd">Смотрите наши работы</a>-->
            </div>
        </div><!-- end container -->
    </div><!-- end section -->
	
	<div id = "seo" class = "container"><hr>
	<h3 class = "mycenter"><span class = "myblue">СпецМонтажСервис</span> монтаж винтовых свай</h3>
	<hr>
	<p>Бесплатный выезд на замер и расчет сметы - <strong><?=  Yii::$app->params['sitePhone'];?></strong><br>
	<strong><?=  Yii::$app->params['siteEmail'];?></strong><br>
	Работаем ежедневно с 08:00 до 21:00
	</p>
	<p>
	<ul
	  <li>Обслуживаем все районы Воронежа и области</li>
      <li>Работаем без предоплаты</li> 
      <li>Гарантия на работы - 3 года</li> 
      <li>Составляем договор</li> 
      <li>Работаем быстро, никого не напрягая</li> 
      <li>Полностью все убираем за собой</li> 
      <li>Оплата наличными, на карту или на р/с</li> 
      <li>Работаем с 2015 года</i>  
	</ul>
	</p>
	<p>Готовы ответить на вопросы ежедневно с 08:00 до 21:00 по телефону <?=  Yii::$app->params['sitePhone'];?>.<br>

Звоните! Расскажем, покажем, объясним, поможем.</p>
	<p>Работаем с помощью
	парка специализированной техники, предназначенной непосредственно для установки 
	свайно-винтового фундамента - самоходная установка Гудвинт, Сваекрут Feller SV-15.</p>
	<h4 class = "mycenter">Как заказать фундамент на винтовых сваях в Воронеже?</h4>
	<p>В любое время вы можете получить консультацию, вызвать мастера на ваш участок или просто написать нам 
	на почту. С каждым клиентом заключаем договор с гарантией 3 года на работы.</p> 
	<p>У компании «СпецМонтажСервис» нет посредников, непосредственно исполняем все работы, связанные с монтажом 
	свайно-винтового фундамента в Воронеже и Воронежской области. Предлагаем выгодные цены
	на сваи и установку. Для постоянных клиентов есть специальные партнерские условия.
	А всем заказчикам, оставившим заявку на нашем сайте, мы предоставляем 5-% скидку.</p>
	<p>Выбирая компанию «СпецМонтажСервис», вы выбираете качество и надежность изготовления
	фундаментов на винтовых сваях в Воронеже!</p> 
   <p>При производстве свай мы используем только новые стальные трубы ГОСТ 10704-91 и 10705-80 со 
   стенкой 4 мм по всей длине ✳ Лопасть изготовлена из металла 5,0 мм. ✳ Обрабатываем антикоррозийной
   двухкомпонентной эмалью ✳ Выполняем монтаж свай в полном соответствии со СНиП ✳ Отклонение сваи
   от вертикальной оси не превышает 1% ✳ Завинчиваем сваи до неподвижных слоев грунта.</p>
<p> ✅ Готовность к восприятию проектной нагрузки сразу же после возведения</p> 
  <p>✅ Высокие прочностные и нагрузочные характеристики: имеют запас несущей способности от 4 т. До 18 т. 
(при необходимых 2–3 т. Для деревянных строений; 7–9 т. Для кирпичных сооружений), более того, 
показатели несущей способности возможно увеличить за счет увеличения диаметра сваи и её лопасти </p>
<p>✅ Договор. Гарантия 3 года. Оплата наличными, на карту или на р/с с НДС%20</p>
<p> Добавьте этот сайт
 в ⭐ Избранное, чтобы не потерять.</p>
 <p>☎ Звоните прямой сейчас, ответим на все Ваши вопросы. 
 ЗВОНОК НАМ СЕГОДНЯ - РЕЗУЛЬТАТ УЖЕ ЗАВТРА!</p>
<p> Виды фундамента, которые можно
 заменить винтовыми сваями: - Свайный ростверк / Свайно-ростверковый / плита с ростверком - 
 монолитная плита классическая - утеплённая плита - ребристая плавающая плита РПП - ленточные 
 фундаменты (различного сечения) - цоколь / колонны - плиты перекрытия / шведская плита - подпорные 
 стенки - монолитные заезды на участок</p>
 <p>Изготавливаем и монтируем конструкции из металла любой конфигурации и сложности.</p>
 <p>Наши услуги - <a href = "<?= Url::to(['site/services']) ?>"><span class = "myred">здесь</span></a>.
 </p>
<p>Цены на винтовые сваи <a href ="<?= Url::to(['site/prices']) ?>"><span class = "myred">здесь</span></a></p>
<p><strong>Как мы работаем:</strong>
<ul> 
<li>Вы звоните нам по телефону</li>
<li>Или оставляете заявку по электронной почте</li>
<li>Мы связываемся с вами, отвечаем на вопросы</li>
<li>Бесплатно рассчитываем смету без доплат потом</li>
<li>Выполняем заказ</li>
<li>Только после этого оплачиваете работу</li>
<li>У вас надежный фундамент с гарантией 3 года</li>
</ul>
</p>
<p>Звоните - <strong><?=  Yii::$app->params['sitePhone'];?></strong></p>
<hr><hr>

	</div>
	
	
	<!-- Start Clients brand -->
  <section id="clients-brand">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="clients-brand-area">
            <ul class="clients-brand-slide">
              <li class="col-md-3">
                <div class="single-brand">
				   <?= Html::img("@web/images/agroinvest.png", ['alt' => 'Агроинвест'])?>
                </div>
              </li>
              <li class="col-md-3">
                <div class="single-brand">
				   <?= Html::img("@web/images/krestyanskie-usory.png", ['alt' => 'Крестьянские узоры'])?>
                </div>
              </li>
              <li class="col-md-3">
                <div class="single-brand">
				  <?= Html::img("@web/images/oleina.png", ['alt' => 'Олейна'])?>
                </div>
              </li>
              <li class="col-md-3">
                <div class="single-brand">
				    <?= Html::img("@web/images/bionorica.png", ['alt' => 'Биороника'])?>
                </div>
              </li>
           
            </ul><hr>
          </div>
        </div>
      </div>
    </div>
  </section><hr>
