<?php

use yii\helpers\Html;
use yii\helpers\Url;

?>

<div id="services" class="parallax section lb ">
        <div class="container">
            <div class="section-title text-center">
                <h1>КОНСТРУКЦИИ ИЗ МЕТАЛЛА</h1>
                <p class="lead">Изготовление и монтаж любой конфигурации и сложности</p>
            </div>
			<p>
			  <?= Html::img("@web/images/gudvint.jpg", ['alt' => 'Самоходная установка Гудвинт', 'class' => 'img-responsive img-rounded'])?>
            </p>
			
<p>	
 Самоходная установка Гудвинт. Наша установка Гудвинт способна на монтаж винтовых свай до 70шт. В день
</p>
<hr>		
            <p>   
              <?= Html::img("@web/images/feller.jpg", ['alt' => ' Сваекрут Feller SV-15', 'class' => 'img-responsive img-rounded'])?>
            </p>    
<p>
 Сваекрут Feller SV-15
</p>

           
			  
			<hr class="hr1">

            <div class="text-center">
                <a data-scroll href="#portfolio" class="btn btn-light btn-radius btn-brd">Звоните нам: +7 920 224 46 62</a>
            </div>
        </div><!-- end container -->
    </div><!-- end section -->