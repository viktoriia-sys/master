<?php
use yii\helpers\Html;
?>
<div id="portfolio" class="section wb">
        <div class="container">
            <div class="section-title text-center">
                <h1>СпецМонтажСервис | Наши работы</h1>
                <p class="lead">Примеры монтажа винтовых свай. За год работы мы выполнили сотни проектов <br>
				Некоторые работы на фото ниже:
				</p>
            </div><!-- end title -->
        </div><!-- end container -->

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <nav class="portfolio-filter text-center">
                        <ul>
                            <li><a class="btn btn-dark btn-radius btn-brd active" href="#" data-filter="*"><span class="oi hidden-xs" data-glyph="grid-three-up"></span>Все</a></li>
                            <li><a class="btn btn-dark btn-radius btn-brd" data-toggle="tooltip" data-placement="top" title="5" href="#" data-filter=".cat1">Орел</a></li>
                            <li><a class="btn btn-dark btn-radius btn-brd" href="#" data-toggle="tooltip" data-placement="top" title="12" data-filter=".cat2">Ранино</a></li>
                            <li><a class="btn btn-dark btn-radius btn-brd" href="#" data-toggle="tooltip" data-placement="top" title="21" data-filter=".cat3">Тамбов</a></li>
                            <li><a class="btn btn-dark btn-radius btn-brd" href="#" data-toggle="tooltip" data-placement="top" title="11" data-filter=".cat4">Воронеж</a></li>
                        </ul>
                    </nav>
                </div>
            </div>

            <hr class="invis">

            <div id="da-thumbs" class="da-thumbs portfolio">
                <div class="post-media pitem item-w1 item-h1 cat1">
                    <a href="images/orel.jpg" data-rel="prettyPhoto[gal]">
					    <?= Html::img("@web/images/orel.jpg", ['alt' => 'Монтаж свай Орел' , 'class' => 'img-responsive'])?>
                          <div>
                            <h3>Орел <small>СпецМонтажСервис</small></h3>
                            <i class="flaticon-unlink"></i>
                          </div>
                    </a>
                </div>
                <div class="post-media pitem item-w1 item-h1 cat2">
                    <a href="images/ranino.jpg" data-rel="prettyPhoto[gal]">
					    <?= Html::img("@web/images/ranino.jpg", ['alt' => 'Монтаж свай Ранино' , 'class' => 'img-responsive'])?>
                       
                        <div>
                            <h3>Ранино <small>СпецМонтажСервис</small></h3>
                            <i class="flaticon-unlink"></i>
                        </div>
                    </a>
                </div>
                <div class="post-media pitem item-w1 item-h1 cat3">
                    <a href="images/tambov1.jpg" data-rel="prettyPhoto[gal]">
					     <?= Html::img("@web/images/tambov1.jpg", ['alt' => 'Монтаж свай Тамбов' , 'class' => 'img-responsive'])?>
                     
                        <div>
                            <h3>Тамбов <small>СпецМонтажСервис</small></h3>
                            <i class="flaticon-unlink"></i>
                        </div>
                    </a>
                </div>
                <div class="post-media pitem item-w1 item-h1 cat3">
                    <a href="images/tambov2.jpg" data-rel="prettyPhoto[gal]">
					     <?= Html::img("@web/images/tambov2.jpg", ['alt' => 'Монтаж свай Тамбов' , 'class' => 'img-responsive'])?>
                           <div>
                            <h3>Тамбов <small>СпецМонтажСервис</small></h3>
                            <i class="flaticon-unlink"></i>
                            </div>
                    </a>
                </div>
                <div class="post-media pitem item-w1 item-h1 cat4">
                    <a href="images/voronezg.jpg" data-rel="prettyPhoto[gal]">
					     <?= Html::img("@web/images/voronezg.jpg", ['alt' => 'Монтаж свай Воронеж' , 'class' => 'img-responsive'])?>
                           <div>
                            <h3>Воронеж <small>СпецМонтажСервис</small></h3>
                            <i class="flaticon-unlink"></i>
                           </div>
                    </a>
                </div>
                <div class="post-media pitem item-w1 item-h1 cat4">
                    <a href="images/voronezh2.jpg" data-rel="prettyPhoto[gal]">
                        <?= Html::img("@web/images/voronezh2.jpg", ['alt' => 'Монтаж свай Воронеж' , 'class' => 'img-responsive'])?>
                        <div>
                            <h3>Воронеж <small>СпецМонтажСервис</small></h3>
                            <i class="flaticon-unlink"></i>
                        </div>
                    </a>
                </div>
                <div class="post-media pitem item-w1 item-h1 cat4">
                    <a href="images/voronezh3.jpg" data-rel="prettyPhoto[gal]">
                        <?= Html::img("@web/images/voronezh3.jpg", ['alt' => 'Монтаж свай Воронеж' , 'class' => 'img-responsive'])?>
                        <div>
                            <h3>Воронеж <small>СпецМонтажСервис</small></h3>
                            <i class="flaticon-unlink"></i>
                        </div>
                    </a>
                </div>
                <div class="post-media pitem item-w1 item-h1 cat4">
                    <a href="images/voronezh4.jpg" data-rel="prettyPhoto[gal]">
                        <?= Html::img("@web/images/voronezh4.jpg", ['alt' => 'Монтаж свай Воронеж' , 'class' => 'img-responsive'])?>
                        <div>
                            <h3>Воронеж <small>СпецМонтажСервис</small></h3>
                            <i class="flaticon-unlink"></i>
                        </div>
                    </a>
                </div>
                <div class="post-media pitem item-w1 item-h1 cat4">
                    <a href="images/voronezh5.jpg" data-rel="prettyPhoto[gal]">
                        <?= Html::img("@web/images/voronezh5.jpg", ['alt' => 'Монтаж свай Воронеж' , 'class' => 'img-responsive'])?>
                        <div>
                            <h3>Воронеж <small>СпецМонтажСервис</small></h3>
                            <i class="flaticon-unlink"></i>
                        </div>
                    </a>
                </div>

                <div class="post-media pitem item-w1 item-h1 cat4">
                    <a href="images/voronezh6.jpg" data-rel="prettyPhoto[gal]">
                       <?= Html::img("@web/images/voronezh6.jpg", ['alt' => 'Монтаж свай Воронеж' , 'class' => 'img-responsive'])?>
                        <div>
                            <h3>Воронеж <small>СпецМонтажСервис</small></h3>
                            <i class="flaticon-unlink"></i>
                        </div>
                    </a>
                </div>
            </div><!-- end portfolio -->
        </div><!-- end container -->
    </div><!-- end section -->