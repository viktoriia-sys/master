<?php
use yii\helpers\Html;
use yii\helpers\Url;
$this->params['breadcrumbs'][] = $this->title;
?>


 <div id="services" class="parallax section lb">
        <div class="container">
            <div class="section-title text-center">
                <h1>СпецМонтажСервис</h1>
                <p class="lead"> 
				  Изготовление и монтаж любой конфигурации и сложности конструкций из металла
                </p>
            </div>
            <div class="owl-services owl-carousel owl-theme">
                <div class="service-widget">
                    <div class="post-media wow fadeIn">
					    <a href="<?= Url::to(['site/works']) ?>">
                        <?= Html::img("@web/images/orel.jpg", ['alt' => 'Фото работ СпецМонтажСервис' , 'class' => 'img-responsive img-rounded'])?>
						</a>
                    </div>
					<div class="service-dit">
						<p class = "myh3"><a href="<?= Url::to(['site/works']) ?>">Фото/Видео</a></p>
						<p></p>
					</div>
                </div>
               

                <div class="service-widget">
                    <div class="post-media wow fadeIn">
					  <a href="<?= Url::to(['site/equipment']) ?>">
                       <?= Html::img("@web/images/feller.jpg", ['alt' => 'Техника СпецМонтажСервис' , 'class' => 'img-responsive img-rounded'])?>
                      </a>
                    </div>
					<div class="service-dit">
						<p class = "myh3"><a href="<?= Url::to(['site/equipment']) ?>">Наша техника</a></p>
						<p></p>
					</div>
                </div>
               

                <div class="service-widget">
                    <div class="post-media wow fadeIn">
					    <a href="<?= Url::to(['site/staff']) ?>">
                        <?= Html::img("@web/images/about_01.jpg", ['alt' => 'Сотрудники СпецМонтажСервис' , 'class' => 'img-responsive img-rounded'])?>
                        </a>
                    </div>
					<div class="service-dit">
						<p class = "myh3"><a href="<?= Url::to(['site/staff']) ?>">Сотрудники</a></p>
						<p></p>
					</div>
                </div>
               
        </div>

            
        </div>
    </div>

