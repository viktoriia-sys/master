<?php

use yii\helpers\Html;
$this->params['breadcrumbs'][] = $this->title;
?>

<div id="services" class="parallax section lb">
        <div class="container">
            <div class="section-title text-center">
                <h1>КОНСТРУКЦИИ ИЗ МЕТАЛЛА</h1>
                <p class="lead">Изготовление и монтаж любой конфигурации и сложности</p>
            </div>
			
			<div class="owl-services owl-carousel owl-theme">
                <div class="service-widget">
                    <div class="post-media wow fadeIn">
                        <?= Html::img("@web/images/service_01.jpg", ['alt' => 'Студенту', 'class' => 'img-responsive img-rounded'])?>
                    </div>
					<div class="service-dit">
						<h3>Винтовые сваи</h3>
						<p></p>
					</div>
                </div>
                <!-- end service -->

                <div class="service-widget">
                    <div class="post-media wow fadeIn">
                        <?= Html::img("@web/images/service_04.jpg", ['alt' => 'Студенту', 'class' => 'img-responsive img-rounded'])?>
                    </div>
					<div class="service-dit">
						<h3>Заборы</h3>
						<p> </p>
					</div>
                </div>
                <!-- end service -->

                <div class="service-widget">
                    <div class="post-media wow fadeIn">
                       <?= Html::img("@web/images/stairway.jpg", ['alt' => 'Студенту', 'class' => 'img-responsive img-rounded'])?>
                    </div>
					<div class="service-dit">
						<h3>Лестницы, перила и поручни</h3>
						<p></p>
					</div>
                </div>
                <!-- end service -->

              </div><!-- end row -->
			  
			  
			<div class="owl-services owl-carousel owl-theme">
                <div class="service-widget">
                    <div class="post-media wow fadeIn">
                        <?= Html::img("@web/images/baki.jpg", ['alt' => 'Студенту', 'class' => 'img-responsive img-rounded'])?>
                    </div>
					<div class="service-dit">
						<h3>Баки и емкости</h3>
						<p></p>
					</div>
                </div>
                <!-- end service -->

                <div class="service-widget">
                    <div class="post-media wow fadeIn">
                        <?= Html::img("@web/images/roof.jpg", ['alt' => 'Студенту', 'class' => 'img-responsive img-rounded'])?>
                    </div>
					<div class="service-dit">
						<h3>Крыши из металлического профиля</h3>
						<p> </p>
					</div>
                </div>
                <!-- end service -->

                <div class="service-widget">
                    <div class="post-media wow fadeIn">
                        <?= Html::img("@web/images/otboi.jpg", ['alt' => 'Студенту', 'class' => 'img-responsive img-rounded'])?>
                    </div>
					<div class="service-dit">
						<h3>Отбойники</h3>
						<p></p>
					</div>
                </div>
                <!-- end service -->

              </div><!-- end row -->
			  
			   
			   <div class="owl-services owl-carousel owl-theme">
                <div class="service-widget">
                    <div class="post-media wow fadeIn">
                        <?= Html::img("@web/images/steam.jpg", ['alt' => 'Студенту', 'class' => 'img-responsive img-rounded'])?>
                    </div>
					<div class="service-dit">
						<h3>Паропроводы</h3>
						<p></p>
					</div>
                </div>
                <!-- end service -->

                <div class="service-widget">
                    <div class="post-media wow fadeIn">
                        <?= Html::img("@web/images/shop.jpg", ['alt' => 'Студенту', 'class' => 'img-responsive img-rounded'])?>
                    </div>
					<div class="service-dit">
						<h3>Входные группы</h3>
						<p> </p>
					</div>
                </div>
                <!-- end service -->

                <div class="service-widget">
                    <div class="post-media wow fadeIn">
                        <?= Html::img("@web/images/corn.jpg", ['alt' => 'Студенту', 'class' => 'img-responsive img-rounded'])?>
                    </div>
					<div class="service-dit">
						<h3>Самотечное оборудование для зерна</h3>
						<p></p>
					</div>
                </div>
                <!-- end service -->

              </div><!-- end row -->
			  
			  <hr class="hr1">

            <div class="text-center">
                <a data-scroll href="#portfolio" class="btn btn-light btn-radius btn-brd">Звоните нам: +7 920 224 46 62</a>
            </div>
        </div><!-- end container -->
    </div><!-- end section -->