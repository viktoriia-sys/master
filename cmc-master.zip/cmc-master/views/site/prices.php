<?php

use yii\helpers\Html;
$this->params['breadcrumbs'][] = $this->title;
?>

<section class="section-table cid-roB6X8tZuD" id="table1-7">

  <div class="container container-table">
      <h1 class = "mycenter">Винтовые сваи цены</h1>
	  <p>Сколько стоят винтовые сваи. Винтовые сваи СВС-57 (нагрузка до 1 т),
	  СВС-76 (нагрузка до 2 т), СВС-89 (нагрузка до 4 т), СВС-108 (нагрузка до 6 т),
	  СВС-133 (нагрузка до 10 т), СВС-159 (нагрузка до 15 т), СВС-219 (нагрузка до 30 т), 
	  СВС-325 (нагрузка до 50 т). Винтовые сваи Воронеж цены с установкой подробно в таблице ниже:</p>
	  <hr>
      <p><strong>Винтовые сваи СВС-57 (нагрузка до 1 т)</strong></div>
	  </p>
      <div class="table-wrapper">
        <div class="container">
          
        </div>

        <div class="container scroll">
          <table class="table" cellspacing="0">
            <thead>
              <tr class="table-heads ">
                  
                  
                  
                  
              <th class="head-item mbr-fonts-style display-7">
                      Наименование</th><th class="head-item mbr-fonts-style display-7">
                      D, мм</th><th class="head-item mbr-fonts-style display-7">
                      Толщина стенки, мм</th><th class="head-item mbr-fonts-style display-7">
                      Диаметр лопасти, мм</th><th class="head-item mbr-fonts-style display-7">
                      Длина, м</th><th class="head-item mbr-fonts-style display-7">
                      Сваи (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Оголовки (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость завинчивания свай (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость сваи "под ключ"</th></tr>
            </thead>

            <tbody>
              
              
              
              
            <tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-57*3,5-2,0</td><td class="body-item mbr-fonts-style display-7">57</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">2</td><td class="body-item mbr-fonts-style display-7">1050</td><td class="body-item mbr-fonts-style display-7">150</td><td class="body-item mbr-fonts-style display-7">1000</td><td class="body-item mbr-fonts-style display-7">2200</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-57*3,5-2,5</td><td class="body-item mbr-fonts-style display-7">57</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">2,5</td><td class="body-item mbr-fonts-style display-7">1200</td><td class="body-item mbr-fonts-style display-7">150</td><td class="body-item mbr-fonts-style display-7">1000</td><td class="body-item mbr-fonts-style display-7">2350</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-57*3,5-3,0</td><td class="body-item mbr-fonts-style display-7">57</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">3</td><td class="body-item mbr-fonts-style display-7">1350</td><td class="body-item mbr-fonts-style display-7">150</td><td class="body-item mbr-fonts-style display-7">1200</td><td class="body-item mbr-fonts-style display-7">2700</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-57*3,5-3,5</td><td class="body-item mbr-fonts-style display-7">57</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">1550</td><td class="body-item mbr-fonts-style display-7">150</td><td class="body-item mbr-fonts-style display-7">1200</td><td class="body-item mbr-fonts-style display-7">2900</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-57*3,5-4,0</td><td class="body-item mbr-fonts-style display-7">57</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">1700</td><td class="body-item mbr-fonts-style display-7">150</td><td class="body-item mbr-fonts-style display-7">1400</td><td class="body-item mbr-fonts-style display-7">3250</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-57*3,5-4,5</td><td class="body-item mbr-fonts-style display-7">57</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">1850</td><td class="body-item mbr-fonts-style display-7">150</td><td class="body-item mbr-fonts-style display-7">1600</td><td class="body-item mbr-fonts-style display-7">3600</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-57*3,5-5,0</td><td class="body-item mbr-fonts-style display-7">57</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">5</td><td class="body-item mbr-fonts-style display-7">2000</td><td class="body-item mbr-fonts-style display-7">150</td><td class="body-item mbr-fonts-style display-7">1800</td><td class="body-item mbr-fonts-style display-7">3950</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-57*3,5-5,5</td><td class="body-item mbr-fonts-style display-7">57</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">5,5</td><td class="body-item mbr-fonts-style display-7">2150</td><td class="body-item mbr-fonts-style display-7">150</td><td class="body-item mbr-fonts-style display-7">2000</td><td class="body-item mbr-fonts-style display-7">4300</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-57*3,5-6,0</td><td class="body-item mbr-fonts-style display-7">57</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">6</td><td class="body-item mbr-fonts-style display-7">2300</td><td class="body-item mbr-fonts-style display-7">150</td><td class="body-item mbr-fonts-style display-7">2200</td><td class="body-item mbr-fonts-style display-7">4650</td></tr></tbody>
          </table>
        </div>
        <div class="container table-info-container">
          
        </div>
      </div>
    </div>
</section>

<section class="section-table cid-roBcscrkzL" id="table1-8">

  
  
  <div class="container container-table">
      
      <h3 class="mbr-section-subtitle mbr-fonts-style align-center pb-5 mbr-light display-5"><br><div><strong>Винтовые сваи СВС-76 (нагрузка до 2 т)</strong></div></h3>
      <div class="table-wrapper">
        <div class="container">
          
        </div>

        <div class="container scroll">
          <table class="table" cellspacing="0">
            <thead>
              <tr class="table-heads ">
                  
                  
                  
                  
              <th class="head-item mbr-fonts-style display-7">
                      Наименование</th><th class="head-item mbr-fonts-style display-7">
                      D, мм</th><th class="head-item mbr-fonts-style display-7">
                      Толщина стенки, мм</th><th class="head-item mbr-fonts-style display-7">
                      Диаметр лопасти, мм</th><th class="head-item mbr-fonts-style display-7">
                      Длина, м</th><th class="head-item mbr-fonts-style display-7">
                      Сваи (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Оголовки (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость завинчивания свай (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость сваи "под ключ"</th></tr>
            </thead>

            <tbody>
              
              
              
              
            <tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-76*3,5-2,0</td><td class="body-item mbr-fonts-style display-7">76</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">2</td><td class="body-item mbr-fonts-style display-7">1350</td><td class="body-item mbr-fonts-style display-7">180</td><td class="body-item mbr-fonts-style display-7">800</td><td class="body-item mbr-fonts-style display-7">2330</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-76*3,5-2,5</td><td class="body-item mbr-fonts-style display-7">76</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">2,5</td><td class="body-item mbr-fonts-style display-7">1550</td><td class="body-item mbr-fonts-style display-7">180</td><td class="body-item mbr-fonts-style display-7">1100</td><td class="body-item mbr-fonts-style display-7">2830</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-76*3,5-3,0</td><td class="body-item mbr-fonts-style display-7">76</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">3</td><td class="body-item mbr-fonts-style display-7">1800</td><td class="body-item mbr-fonts-style display-7">180</td><td class="body-item mbr-fonts-style display-7">1400</td><td class="body-item mbr-fonts-style display-7">3380</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-76*3,5-3,5</td><td class="body-item mbr-fonts-style display-7">76</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">2000</td><td class="body-item mbr-fonts-style display-7">180</td><td class="body-item mbr-fonts-style display-7">1700</td><td class="body-item mbr-fonts-style display-7">3880</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-76*3,5-4,0</td><td class="body-item mbr-fonts-style display-7">76</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">2250</td><td class="body-item mbr-fonts-style display-7">180</td><td class="body-item mbr-fonts-style display-7">2000</td><td class="body-item mbr-fonts-style display-7">4430</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-76*3,5-4,5</td><td class="body-item mbr-fonts-style display-7">76</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">2450</td><td class="body-item mbr-fonts-style display-7">180</td><td class="body-item mbr-fonts-style display-7">2300</td><td class="body-item mbr-fonts-style display-7">4930</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-76*3,5-5,0</td><td class="body-item mbr-fonts-style display-7">76</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">5</td><td class="body-item mbr-fonts-style display-7">2650</td><td class="body-item mbr-fonts-style display-7">180</td><td class="body-item mbr-fonts-style display-7">2600</td><td class="body-item mbr-fonts-style display-7">5430</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-76*3,5-5,5</td><td class="body-item mbr-fonts-style display-7">76</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">5,5</td><td class="body-item mbr-fonts-style display-7">2900</td><td class="body-item mbr-fonts-style display-7">180</td><td class="body-item mbr-fonts-style display-7">2900</td><td class="body-item mbr-fonts-style display-7">5980</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-76*3,5-6,0</td><td class="body-item mbr-fonts-style display-7">76</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">6</td><td class="body-item mbr-fonts-style display-7">3100</td><td class="body-item mbr-fonts-style display-7">180</td><td class="body-item mbr-fonts-style display-7">3200</td><td class="body-item mbr-fonts-style display-7">6480</td></tr></tbody>
          </table>
        </div>
        <div class="container table-info-container">
          
        </div>
      </div>
    </div>
</section>

<section class="section-table cid-roBcsZH7CA" id="table1-9">

  
  
  <div class="container container-table">
      
      <h3 class="mbr-section-subtitle mbr-fonts-style align-center pb-5 mbr-light display-5"><div><br></div><div><strong>Винтовые сваи СВС-89 (нагрузка до 4 т)</strong></div></h3>
      <div class="table-wrapper">
        <div class="container">
          
        </div>

        <div class="container scroll">
          <table class="table" cellspacing="0">
            <thead>
              <tr class="table-heads ">
                  
                  
                  
                  
              <th class="head-item mbr-fonts-style display-7">
                      Наименование</th><th class="head-item mbr-fonts-style display-7">
                      D, мм</th><th class="head-item mbr-fonts-style display-7">
                      Толщина стенки, мм</th><th class="head-item mbr-fonts-style display-7">
                      Диаметр лопасти, мм</th><th class="head-item mbr-fonts-style display-7">
                      Длина, м</th><th class="head-item mbr-fonts-style display-7">
                      Сваи (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Оголовки (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость завинчивания свай (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость сваи "под ключ"</th></tr>
            </thead>

            <tbody>
              
              
              
              
            <tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-89*3,5-2,0</td><td class="body-item mbr-fonts-style display-7">89</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">2</td><td class="body-item mbr-fonts-style display-7">1400</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">1000</td><td class="body-item mbr-fonts-style display-7">2600</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-89*3,5-2,5</td><td class="body-item mbr-fonts-style display-7">89</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">2,5</td><td class="body-item mbr-fonts-style display-7">1500</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">1100</td><td class="body-item mbr-fonts-style display-7">2800</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-89*3,5-3,0</td><td class="body-item mbr-fonts-style display-7">89</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">3</td><td class="body-item mbr-fonts-style display-7">1900</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">1400</td><td class="body-item mbr-fonts-style display-7">3500</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-89*3,5-3,5</td><td class="body-item mbr-fonts-style display-7">89</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">2150</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">1700</td><td class="body-item mbr-fonts-style display-7">4050</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-89*3,5-4,0</td><td class="body-item mbr-fonts-style display-7">89</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">2350</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">1900</td><td class="body-item mbr-fonts-style display-7">4450</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-89*3,5-4,5</td><td class="body-item mbr-fonts-style display-7">89</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">2600</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">2200</td><td class="body-item mbr-fonts-style display-7">5000</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-89*3,5-5,0</td><td class="body-item mbr-fonts-style display-7">89</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">5</td><td class="body-item mbr-fonts-style display-7">2800</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">2500</td><td class="body-item mbr-fonts-style display-7">5500</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-89*3,5-5,5</td><td class="body-item mbr-fonts-style display-7">89</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">5,5</td><td class="body-item mbr-fonts-style display-7">3050</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">2800</td><td class="body-item mbr-fonts-style display-7">6050</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-89*3,5-6,0</td><td class="body-item mbr-fonts-style display-7">89</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">250</td><td class="body-item mbr-fonts-style display-7">6</td><td class="body-item mbr-fonts-style display-7">3300</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">3100</td><td class="body-item mbr-fonts-style display-7">6600</td></tr></tbody>
          </table>
        </div>
        <div class="container table-info-container">
          
        </div>
      </div>
    </div>
</section>

<section class="section-table cid-roBexisgrR" id="table1-a">

  
  
  <div class="container container-table">
      
      <h3 class="mbr-section-subtitle mbr-fonts-style align-center pb-5 mbr-light display-5"><div><br></div><div><strong>Винтовые сваи СВС-108 (нагрузка до 6 т)</strong></div></h3>
      <div class="table-wrapper">
        <div class="container">
          
        </div>

        <div class="container scroll">
          <table class="table" cellspacing="0">
            <thead>
              <tr class="table-heads ">
                  
                  
                  
                  
              <th class="head-item mbr-fonts-style display-7">
                      Наименование</th><th class="head-item mbr-fonts-style display-7">
                      D, мм</th><th class="head-item mbr-fonts-style display-7">
                      Толщина стенки, мм</th><th class="head-item mbr-fonts-style display-7">
                      Диаметр лопасти, мм</th><th class="head-item mbr-fonts-style display-7">
                      Длина, м</th><th class="head-item mbr-fonts-style display-7">
                      Сваи (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Оголовки (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость завинчивания свай (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость сваи "под ключ"</th></tr>
            </thead>

            <tbody>
              
              
              
              
            <tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-108*4,0-2,0</td><td class="body-item mbr-fonts-style display-7">108</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">300</td><td class="body-item mbr-fonts-style display-7">2</td><td class="body-item mbr-fonts-style display-7">1700</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">1100</td><td class="body-item mbr-fonts-style display-7">3000</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-108*4,0-2,5</td><td class="body-item mbr-fonts-style display-7">108</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">300</td><td class="body-item mbr-fonts-style display-7">2,5</td><td class="body-item mbr-fonts-style display-7">1800</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">1200</td><td class="body-item mbr-fonts-style display-7">3200</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-108*4,0-3,0</td><td class="body-item mbr-fonts-style display-7">108</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">300</td><td class="body-item mbr-fonts-style display-7">3</td><td class="body-item mbr-fonts-style display-7">2300</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">1700</td><td class="body-item mbr-fonts-style display-7">4200</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-108*4,0-3,5</td><td class="body-item mbr-fonts-style display-7">108</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">300</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">2600</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">1900</td><td class="body-item mbr-fonts-style display-7">4700</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-108*4,0-4,0</td><td class="body-item mbr-fonts-style display-7">108</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">300</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">2900</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">2200</td><td class="body-item mbr-fonts-style display-7">5300</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-108*4,0-4,5</td><td class="body-item mbr-fonts-style display-7">108</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">300</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">3250</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">2500</td><td class="body-item mbr-fonts-style display-7">5950</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-108*4,0-5,0</td><td class="body-item mbr-fonts-style display-7">108</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">300</td><td class="body-item mbr-fonts-style display-7">5</td><td class="body-item mbr-fonts-style display-7">3550</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">2800</td><td class="body-item mbr-fonts-style display-7">6550</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-108*4,0-5,5</td><td class="body-item mbr-fonts-style display-7">108</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">300</td><td class="body-item mbr-fonts-style display-7">5,5</td><td class="body-item mbr-fonts-style display-7">3850</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">3100</td><td class="body-item mbr-fonts-style display-7">7150</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-108*4,0-6,0</td><td class="body-item mbr-fonts-style display-7">108</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">300</td><td class="body-item mbr-fonts-style display-7">6</td><td class="body-item mbr-fonts-style display-7">4150</td><td class="body-item mbr-fonts-style display-7">200</td><td class="body-item mbr-fonts-style display-7">3400</td><td class="body-item mbr-fonts-style display-7">7750</td></tr></tbody>
          </table>
        </div>
        <div class="container table-info-container">
          
        </div>
      </div>
    </div>
</section>

<section class="section-table cid-roBexMyBCd" id="table1-b">

  
  
  <div class="container container-table">
      
      <h3 class="mbr-section-subtitle mbr-fonts-style align-center pb-5 mbr-light display-5"><div><br></div><div><strong>Винтовые сваи СВС-133 (нагрузка до 10 т)</strong></div></h3>
      <div class="table-wrapper">
        <div class="container">
          
        </div>

        <div class="container scroll">
          <table class="table" cellspacing="0">
            <thead>
              <tr class="table-heads ">
                  
                  
                  
                  
              <th class="head-item mbr-fonts-style display-7">
                      Наименование</th><th class="head-item mbr-fonts-style display-7">
                      D, мм</th><th class="head-item mbr-fonts-style display-7">
                      Толщина стенки, мм</th><th class="head-item mbr-fonts-style display-7">
                      Диаметр лопасти, мм</th><th class="head-item mbr-fonts-style display-7">
                      Длина, м</th><th class="head-item mbr-fonts-style display-7">
                      Сваи (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Оголовки (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость завинчивания свай (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость сваи "под ключ"</th></tr>
            </thead>

            <tbody>
              
              
              
              
            <tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-133*4,5-3,0</td><td class="body-item mbr-fonts-style display-7">133</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">350</td><td class="body-item mbr-fonts-style display-7">3</td><td class="body-item mbr-fonts-style display-7">3100</td><td class="body-item mbr-fonts-style display-7">350</td><td class="body-item mbr-fonts-style display-7">2600</td><td class="body-item mbr-fonts-style display-7">6050</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-133*4,5-3,5</td><td class="body-item mbr-fonts-style display-7">133</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">350</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">3500</td><td class="body-item mbr-fonts-style display-7">350</td><td class="body-item mbr-fonts-style display-7">2600</td><td class="body-item mbr-fonts-style display-7">6450</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-133*4,5-4,0</td><td class="body-item mbr-fonts-style display-7">133</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">350</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">3900</td><td class="body-item mbr-fonts-style display-7">350</td><td class="body-item mbr-fonts-style display-7">2800</td><td class="body-item mbr-fonts-style display-7">7050</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-133*4,5-4,5</td><td class="body-item mbr-fonts-style display-7">133</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">350</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">4400</td><td class="body-item mbr-fonts-style display-7">350</td><td class="body-item mbr-fonts-style display-7">3000</td><td class="body-item mbr-fonts-style display-7">7750</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-133*4,5-5,0</td><td class="body-item mbr-fonts-style display-7">133</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">350</td><td class="body-item mbr-fonts-style display-7">5</td><td class="body-item mbr-fonts-style display-7">4800</td><td class="body-item mbr-fonts-style display-7">350</td><td class="body-item mbr-fonts-style display-7">3400</td><td class="body-item mbr-fonts-style display-7">8550</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-133*4,5-5,5</td><td class="body-item mbr-fonts-style display-7">133</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">350</td><td class="body-item mbr-fonts-style display-7">5,5</td><td class="body-item mbr-fonts-style display-7">5200</td><td class="body-item mbr-fonts-style display-7">350</td><td class="body-item mbr-fonts-style display-7">3800</td><td class="body-item mbr-fonts-style display-7">9350</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-133*4,5-6,0</td><td class="body-item mbr-fonts-style display-7">133</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">350</td><td class="body-item mbr-fonts-style display-7">6</td><td class="body-item mbr-fonts-style display-7">5600</td><td class="body-item mbr-fonts-style display-7">350</td><td class="body-item mbr-fonts-style display-7">4200</td><td class="body-item mbr-fonts-style display-7">10150</td></tr></tbody>
          </table>
        </div>
        <div class="container table-info-container">
          
        </div>
      </div>
    </div>
</section>

<section class="section-table cid-roBeyhRyTS" id="table1-c">

  
  
  <div class="container container-table">
      
      <h3 class="mbr-section-subtitle mbr-fonts-style align-center pb-5 mbr-light display-5"><div><br></div><div><strong>Винтовые сваи СВС-159 (нагрузка до 15 т)</strong></div></h3>
      <div class="table-wrapper">
        <div class="container">
          
        </div>

        <div class="container scroll">
          <table class="table" cellspacing="0">
            <thead>
              <tr class="table-heads ">
                  
                  
                  
                  
              <th class="head-item mbr-fonts-style display-7">
                      Наименование</th><th class="head-item mbr-fonts-style display-7">
                      D, мм</th><th class="head-item mbr-fonts-style display-7">
                      Толщина стенки, мм</th><th class="head-item mbr-fonts-style display-7">
                      Диаметр лопасти, мм</th><th class="head-item mbr-fonts-style display-7">
                      Длина, м</th><th class="head-item mbr-fonts-style display-7">
                      Сваи (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Оголовки (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость завинчивания свай (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость сваи "под ключ"</th></tr>
            </thead>

            <tbody>
              
              
              
              
            <tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-159*4,5-3,0</td><td class="body-item mbr-fonts-style display-7">159</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">500</td><td class="body-item mbr-fonts-style display-7">3</td><td class="body-item mbr-fonts-style display-7">5950</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-159*4,5-3,5</td><td class="body-item mbr-fonts-style display-7">159</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">500</td><td class="body-item mbr-fonts-style display-7">3,5</td><td class="body-item mbr-fonts-style display-7">6700</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-159*4,5-4,0</td><td class="body-item mbr-fonts-style display-7">159</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">500</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">7450</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-159*4,5-4,5</td><td class="body-item mbr-fonts-style display-7">159</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">500</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">8200</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-159*4,5-5,0</td><td class="body-item mbr-fonts-style display-7">159</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">500</td><td class="body-item mbr-fonts-style display-7">5</td><td class="body-item mbr-fonts-style display-7">8950</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-159*4,5-5,5</td><td class="body-item mbr-fonts-style display-7">159</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">500</td><td class="body-item mbr-fonts-style display-7">5,5</td><td class="body-item mbr-fonts-style display-7">9700</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-159*4,5-6,0</td><td class="body-item mbr-fonts-style display-7">159</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">500</td><td class="body-item mbr-fonts-style display-7">6</td><td class="body-item mbr-fonts-style display-7">10900</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-159*4,5-7,0</td><td class="body-item mbr-fonts-style display-7">159</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">500</td><td class="body-item mbr-fonts-style display-7">7</td><td class="body-item mbr-fonts-style display-7">12450</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-159*4,5-7,5</td><td class="body-item mbr-fonts-style display-7">159</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">500</td><td class="body-item mbr-fonts-style display-7">7,5</td><td class="body-item mbr-fonts-style display-7">13250</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr>
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-159*4,5-8,0</td><td class="body-item mbr-fonts-style display-7">159</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">500</td><td class="body-item mbr-fonts-style display-7">8</td><td class="body-item mbr-fonts-style display-7">14050</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr></tbody>
          </table>
        </div>
        <div class="container table-info-container">
          
        </div>
      </div>
    </div>
</section>

<section class="section-table cid-roBeyISABt" id="table1-d">

  
  
  <div class="container container-table">
      
      <h3 class="mbr-section-subtitle mbr-fonts-style align-center pb-5 mbr-light display-5"><div><br></div><div><strong>Винтовые сваи СВС-219 (нагрузка до 30 т)</strong></div></h3>
      <div class="table-wrapper">
        <div class="container">
          
        </div>

        <div class="container scroll">
          <table class="table" cellspacing="0">
            <thead>
              <tr class="table-heads ">
                  
                  
                  
                  
              <th class="head-item mbr-fonts-style display-7">
                      Наименование</th><th class="head-item mbr-fonts-style display-7">
                      D, мм</th><th class="head-item mbr-fonts-style display-7">
                      Толщина стенки, мм</th><th class="head-item mbr-fonts-style display-7">
                      Диаметр лопасти, мм</th><th class="head-item mbr-fonts-style display-7">
                      Длина, м</th><th class="head-item mbr-fonts-style display-7">
                      Сваи (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Оголовки (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость завинчивания свай (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость сваи "под ключ"</th></tr>
            </thead>

            <tbody>
              
              
              
              
            <tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-219*4,5-4,0</td><td class="body-item mbr-fonts-style display-7">219</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">500</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">13150</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-219*4,5-5,0</td><td class="body-item mbr-fonts-style display-7">219</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">500</td><td class="body-item mbr-fonts-style display-7">5</td><td class="body-item mbr-fonts-style display-7">15900</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-219*4,5-6,0</td><td class="body-item mbr-fonts-style display-7">219</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">500</td><td class="body-item mbr-fonts-style display-7">6</td><td class="body-item mbr-fonts-style display-7">19400</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-219*4,5-7,0</td><td class="body-item mbr-fonts-style display-7">219</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">500</td><td class="body-item mbr-fonts-style display-7">7</td><td class="body-item mbr-fonts-style display-7">22300</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-219*4,5-8,0</td><td class="body-item mbr-fonts-style display-7">219</td><td class="body-item mbr-fonts-style display-7">4,5</td><td class="body-item mbr-fonts-style display-7">500</td><td class="body-item mbr-fonts-style display-7">8</td><td class="body-item mbr-fonts-style display-7">25200</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr></tbody>
          </table>
        </div>
        <div class="container table-info-container">
          
        </div>
      </div>
    </div>
</section>

<section class="section-table cid-roBkKu3dcU" id="table1-e">

  
  
  <div class="container container-table">
      
      <h3 class="mbr-section-subtitle mbr-fonts-style align-center pb-5 mbr-light display-5"><div><br></div><div><strong>Винтовые сваи СВС-325 (нагрузка до 50 т)</strong></div></h3>
      <div class="table-wrapper">
        <div class="container">
          
        </div>

        <div class="container scroll">
          <table class="table" cellspacing="0">
            <thead>
              <tr class="table-heads ">
                  
                  
                  
                  
              <th class="head-item mbr-fonts-style display-7">
                      Наименование</th><th class="head-item mbr-fonts-style display-7">
                      D, мм</th><th class="head-item mbr-fonts-style display-7">
                      Толщина стенки, мм</th><th class="head-item mbr-fonts-style display-7">
                      Диаметр лопасти, мм</th><th class="head-item mbr-fonts-style display-7">
                      Длина, м</th><th class="head-item mbr-fonts-style display-7">
                      Сваи (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Оголовки (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость завинчивания свай (руб/шт)</th><th class="head-item mbr-fonts-style display-7">
                      Стоимость сваи "под ключ"</th></tr>
            </thead>

            <tbody>
              
              
              
              
            <tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-325*8,0-4,0</td><td class="body-item mbr-fonts-style display-7">325</td><td class="body-item mbr-fonts-style display-7">8,0</td><td class="body-item mbr-fonts-style display-7">800</td><td class="body-item mbr-fonts-style display-7">4</td><td class="body-item mbr-fonts-style display-7">22500</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-325*8,0-5,0</td><td class="body-item mbr-fonts-style display-7">325</td><td class="body-item mbr-fonts-style display-7">8,0</td><td class="body-item mbr-fonts-style display-7">800</td><td class="body-item mbr-fonts-style display-7">5</td><td class="body-item mbr-fonts-style display-7">27000</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-325*8,0-6,0</td><td class="body-item mbr-fonts-style display-7">325</td><td class="body-item mbr-fonts-style display-7">8,0</td><td class="body-item mbr-fonts-style display-7">800</td><td class="body-item mbr-fonts-style display-7">6</td><td class="body-item mbr-fonts-style display-7">33500</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-325*8,0-7,0</td><td class="body-item mbr-fonts-style display-7">325</td><td class="body-item mbr-fonts-style display-7">8,0</td><td class="body-item mbr-fonts-style display-7">800</td><td class="body-item mbr-fonts-style display-7">7</td><td class="body-item mbr-fonts-style display-7">37750</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr><tr> 
                
                
                
                
              <td class="body-item mbr-fonts-style display-7">СВС-325*8,0-8,0</td><td class="body-item mbr-fonts-style display-7">325</td><td class="body-item mbr-fonts-style display-7">8,0</td><td class="body-item mbr-fonts-style display-7">800</td><td class="body-item mbr-fonts-style display-7">8</td><td class="body-item mbr-fonts-style display-7">42500</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td><td class="body-item mbr-fonts-style display-7">-</td></tr></tbody>
          </table>
        </div>
        <div class="container table-info-container">
          
        </div>
      </div>
    </div>
</section>