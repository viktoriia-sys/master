<?php

$this->params['breadcrumbs'][] = ['label' => 'Блог', 'url' => ['/blog/index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<section class="blog-page-section spad pt-0">
<div class="container">
	<div class="row">
		<div class="col-md-8">
			<div class="post-item post-details">
				<div class="post-content">
					<h1><?= $article->h1 ?></h1>
					<div class="post-meta">
						<span><i class="fa fa-calendar-o"></i> <?= $article->date ?></span>
					</div>
					<?= $article->text ?>
					<div class="tag"><i class="fa fa-tag"></i> СпецМонтажСервис</div>
				</div>
			</div>
		</div>
	</div>
</div>
</section>			
						