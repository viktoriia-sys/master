<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\widgets\LinkPager;

$this->params['breadcrumbs'][] = $this->title;
?>
<section class="blog-page-section spad pt-0">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 post-list">
			
			    <?php foreach($news as $new):?>
			
              <div class="post-item">
				<div class="post-content">
				  <h3><a href="<?= Url::to(['blog/view', 'url' => $new->url]) ?>"><?= $new->link ?></a></h3>
					<div class="post-meta">
						<span><i class="fa fa-calendar-o"></i> <?= $new->date ?></span>
					</div>
					<p><?= $new->short_text?></p>
					<p><a href = "<?= Url::to(['blog/view', 'url' => $new->url]) ?>" class = "btn btn-primary">Читать</a></p>
				</div>
			  </div>
			  <hr>
               <?php endforeach; ?>
			  
			  <?= LinkPager::widget(['pagination' => $pages,]) ;?>
			  
		    </div>			
		</div>
	</div>
</section>