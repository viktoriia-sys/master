<?php

namespace app\controllers;

use yii\web\Response;
use app\models\Article;
use yii\data\Pagination;

class BlogController extends AppController
{
	public function actionIndex()
    {
        $query = Article::find()->orderBy('id DESC');
		$pages = new Pagination(['totalCount' => $query->count(), 'pageSize' => 5, 'forcePageParam' => false, 'pageSizeParam' => false]);
		$news = $query->offset($pages->offset)->limit($pages->limit)->all();
		
		$this->setMeta('Блог | СпецМонтажСервис', 'Интересные статьи о свайно-винтовых фундаментах и строительству | СпецМонтажСервис');
		return $this->render('index', compact('news', 'pages'));
    }
	
	public function actionView($url)
	{
	    $article = Article::find()->where(['url' => $url])->one();
		if($article  === null){
			throw new \yii\web\HttpException(404, 'Такой страницы нет');
		}
		$this->setMeta($article->title, $article->description);
		return $this->render('view', compact('article'));
	}
}