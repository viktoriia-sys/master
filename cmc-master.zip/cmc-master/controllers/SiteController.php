<?php

namespace app\controllers;

use Yii;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;

class SiteController extends AppController
{
    
    /*public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout'],
                'rules' => [
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    } */

   
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    
    public function actionIndex()
    {
        $this->setMeta('Винтовые сваи Воронеж. Монтаж свайно-винтового фундамента | СпецМонтажСервис
', 'Монтаж винтовых свай в Воронеже и области. 
Выезд на замер и расчет бесплатно.
Большой опыт работы. Тел: +7 920 224 46 62. Звоните!');
		return $this->render('index');
    }

   
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }

        $model->password = '';
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    
    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
		$this->setMeta('Контакты СпецМонтажСервис',
		'Контакты СпецМонтажСервис Воронеж, ул. Пирогова д. 87Б оф. 202/7, Телефон +7 920 224 46 62 ');
        return $this->render('contact', [
            'model' => $model,
        ]);
    }

    
    public function actionAbout()
    {
        $this->setMeta('СпецМонтажСервис о компании',
		'Информация о СпецМонтажСервис Воронеж. Фото, техника, сотрудники.');
		return $this->render('about');
    }
	
	public function actionPrices()
    {
        $this->setMeta('Цены на винтовые сваи | СпецМонтажСервис',
		'Цены на Ввинтовые сваи. Подробно в таблице');
		return $this->render('prices');
    }
	
	public function actionServices()
    {
        $this->setMeta('СпецМонтажСервис услуги по монтажу винтовых свай',
		'СпецМонтажСервис изготовление и монтаж конструкций из металла любой конфигурации и сложности');
		return $this->render('services');
    }
	
	public function actionWorks()
    {
        $this->setMeta('Фото работ по монтажу винтовых свай | СпецМонтажСервис',
		'Фото работ по монтажу винтовых свай. Воронеж, Орел, Тамбов..');
		return $this->render('works');
    }
	
	public function actionFaq()
    {
        $this->setMeta('FAQ часто задаваемые вопросы | СпецМонтажСервис',
		'FAQ часто задаваемые вопросы по винтовым сваям | СпецМонтажСервис');
		return $this->render('faq');
    }
	
	public function actionEquipment()
    {
         $this->setMeta('Техника для монтажа винтовых свай | СпецМонтажСервис',
		'Техника для монтажа винтовых свай. Самоходная установка Гудвинт, Сваекрут Feller SV-15 | СпецМонтажСервис');
		return $this->render('equipment');
    }
	
	public function actionStaff()
    {
         $this->setMeta('Сотрудники | СпецМонтажСервис',
		'Сотрудники компании СпецМонтажСервис');
		return $this->render('staff');
    }
	
}
